Vue.component('v-chart', VueECharts);
Vue.component('ranking', httpVueLoader('components/Ranking.vue'));

var store = {
    quiz: null,
    localizerStrings: {},
    idiomaSelecionado: '',
    idiomasDisponiveis: ['pt-br', 'en']
};

Vue.mixin({
    data: function () {
        return store;
    },
    methods: {
        traducao: function (key) {
            return store.localizerStrings[key] || key;
        }
    }
});

var router = new VueRouter({
    routes: [
        { name: 'home', path: '/', component: httpVueLoader('components/Home.vue') },
        { name: 'quiz', path: '/quiz/:pin/:nick', component: httpVueLoader('components/Quiz.vue') },
        { name: 'criar', path: '/criar', component: httpVueLoader('components/Questions.vue') },
    ]
});

var app = new Vue({
    el: '#app',
    router: router,
    methods: {
        carregarIdioma: function (idioma) {
            store.idiomaSelecionado = idioma;
            $.get('lang/' + idioma + '.json').done(function (strings) {
                store.localizerStrings = strings;
            }).fail(function () {
                store.localizerStrings = {};
            });
        }
    },
    created: function () {
        this.carregarIdioma('pt-br');
    }
});
<template>
    <div>
        <div v-for="questionario in questionarios">
           {{questionario.nome}}
        </div>
    </div>
</template>

<script>
    module.exports = {
        data: function() {
            return {
                questionarios: []
            };
        },
        created: function() {
            api.getQuestionarios().then((questionarios) => {
                this.questionarios = questionarios;
            });
        }
    }
</script>

<style scoped>
</style>
<template>
  <div class="form-signin">
    <h2 class="cover-heading mb-4">{{traducao('Jogar')}}</h2>
    <div class="lead">
      <input type="text" class="form-control" v-model="pin" :placeholder="traducao('Pin')">
      <input type="text" class="form-control" v-model="nick" :placeholder="traducao('Nick')">
    </div>
    <button type="button" class="btn btn-lg btn-secondary btn-block mt-2" @click="enterQuiz()">{{traducao('Entrar')}}</button>
  </div>
</template>

<script>
module.exports = {
  data: function () {
    return {
      pin: '',
      nick: ''
    };
  },
  methods: {
    enterQuiz: function () {
      if (!this.pin || !this.nick)
        return;
      enterQuiz(this.pin, this.nick).then((response) => {
        if (response.success) {
          router.push({ name: 'quiz', params: {pin: this.pin, nick: this.nick} });
          this.pin = '';
          this.nick = '';
        }
      });
    }
  }
}
</script>

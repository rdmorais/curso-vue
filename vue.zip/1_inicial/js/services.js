// const serverUrl = "";
const serverUrl = "https://curso-vue.azurewebsites.net";

/* api client ================================================================*/
const apiUrl = serverUrl + "/api";

const api = {
  getToken: function (userid) {
    userid = userid || '';
    return new Promise(function (resolve, reject) {
      var token = localStorage.getItem('buzz_quiz_token');
      if (token) {
        resolve(token);
        return;
      }
      $.ajax({
        type: "GET",
        url: apiUrl + '/questionario/token/' + userid,
        dataType: "text"
      }).done(function (response) {
        localStorage.setItem('buzz_quiz_token', response);
        resolve(response);
      }).fail(reject);
    });
  },
  ajax: function (options) {
    return new Promise((resolve, reject) => {
      this.getToken().then(function (token) {
        options.beforeSend = function (xhr) {
          xhr.setRequestHeader('Authorization', 'Bearer ' + token);
        };
        $.ajax(options).done(resolve).fail(reject);
      }).catch(reject);
    });
  },
  getQuestionarios: function () {
    return this.ajax({
      type: "GET",
      url: apiUrl + '/questionario',
      dataType: "json"
    });
  },
  getQuestionario: function (id) {
    return this.ajax({
      type: "GET",
      url: apiUrl + '/questionario/' + id,
      dataType: "json"
    });
  },
  salvarQuestionario: function (questionario) {
    return this.ajax({
      type: "POST",
      url: apiUrl + '/questionario',
      dataType: "json",
      contentType: "application/json",
      data: JSON.stringify(questionario)
    });
  },
  admin1: function () {
    localStorage.removeItem('buzz_quiz_token');
    this.getToken('admin1');
  }
};

/* signalR connection ========================================================*/
var quizHub = new signalR.HubConnectionBuilder().withUrl(serverUrl + "/quizHub", {
  skipNegotiation: true,
  transport: signalR.HttpTransportType.WebSockets,
  accessTokenFactory: api.getToken
}).build();

quizHub.onclose(function(error) {
  swal({
    title: error,
    icon: "error"
  }).then(function () {
    location.reload();
  });
});

function enterQuiz(pin, nick) {
  return new Promise(function (resolve, reject) {
    if (!pin || !nick)
    return;
    quizHub.invoke('Entrar', pin, nick).then((response) => {
      if (!response.success) {
        swal({
          title: traducao(response.message),
          icon: "warning"
        });
      }
      resolve(response);
    }).catch(reject);
  });
}

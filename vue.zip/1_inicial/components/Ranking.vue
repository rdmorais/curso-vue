<template>
  <div class="ranking">
    <v-chart :options="rankingOptions" autoresize/>
  </div>
</template>

<style>
.echarts {
  width: auto !important;
  height: 400px !important;
}
</style>

<script>
module.exports = {
  props: ['jogadores', 'meu'],
  computed: {
    rankingOptions: function () {
      if (!this.jogadores) return null;
      var ordenado = this.jogadores.slice();
      ordenado.sort(function (a, b) {
        return a.pontos - b.pontos;
      });
      return {
        textStyle: {
          color: '#fff'
        },
        xAxis: {
          type: 'value',
          splitLine: {
            show: false
          }
        },
        yAxis: {
          type: 'category',
          data: ordenado.map(j => j.nick),
          axisLine: {
            lineStyle: {
              color: 'rgba(225, 225, 225, 0.5)'
            }
          }
        },
        series: [{
          data: ordenado.map(j => (j === this.meu) ? {itemStyle: {color: '#099'}, value: j.pontos} : j.pontos),
          type: 'bar',
          showBackground: true,
          backgroundStyle: {
            color: 'rgba(225, 225, 225, 0.1)'
          },
          label: {
            show: true
          }
        }]
      };
    }
  }
}
</script>

<template>
  <div class="page-quiz">
    <div v-if="!quiz">
      <h3 class="cover-heading">{{traducao('Carregando...')}}</h3>
    </div>
    <div v-if="quiz && !perguntaAtual && !concluido">
      <h3 class="cover-heading">{{traducao('Aguarde o jogo iniciar')}}</h3>
    </div>
    <div v-if="quiz && !perguntaAtual && concluido">
      <ranking :jogadores="quiz.jogadores" :meu="meuJogador"></ranking>
    </div>
    <div v-if="quiz && perguntaAtual" class="text-left">
      <h5 class="pb-3 rounded d-flex">
        <span class="flex-fill">{{meuJogador.nick}}</span>
        <div class="ml-3">
          <i class="icon icon-help align-middle"></i>
          <span class="align-middle">{{quiz.perguntaAtualIndex + 1}}/{{quiz.perguntas.length}}</span>
        </div>
        <div class="ml-3">
          <i class="icon icon-group align-middle"></i>
          <span class="align-middle">{{quiz.jogadores.length}}</span>
        </div>
        <div class="ml-3">
          <i class="icon icon-trophy align-middle"></i>
          <span class="align-middle">{{quiz.jogadores.indexOf(meuJogador) + 1}}</span>
        </div>
        <div class="ml-3">
          <i class="icon icon-star align-middle"></i>
          <span class="align-middle">{{meuJogador.pontos}}</span>
        </div>
      </h5>
      <h5 class="enunciado p-3 rounded">{{perguntaAtual.enunciado}}</h5>
      <div class="row">
        <div v-for="(escolha, index) in perguntaAtual.escolhas" class="escolha col-md-6 p-3">
          <div class="escolha-text p-3 rounded d-flex" @click="responder(index)" :class="getClassEscolha(index)">
            <span class="flex-fill">{{escolha}}</span>
            <i class="icon icon-check" v-if="respondida && index === perguntaAtual.resposta"></i>
            <i class="icon icon-clear" v-if="respondida && index !== perguntaAtual.resposta"></i>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
module.exports = {
  computed: {
    perguntaAtual: function () {
      try {
        return this.quiz.perguntas[this.quiz.perguntaAtualIndex];
      } catch (e) {
        return null;
      }
    },
    meuJogador: function () {
      try {
        this.quiz.jogadores.sort(function (a, b) {
          return b.pontos - a.pontos;
        });
        return this.quiz.jogadores.find(j => j.nick === this.$route.params.nick);
      } catch (e) {
        return null;
      }
    },
    respondida: function () {
      try {
        return this.meuJogador.respondidas[this.quiz.perguntaAtualIndex] != null;
      } catch (e) {
        return null;
      }
    },
    concluido: function () {
      try {
        return this.quiz.perguntaAtualIndex >= this.quiz.perguntas.length;
      } catch (e) {
        return false;
      }
    }
  },
  methods: {
    responder: function (resposta) {
      quizHub.invoke('Responder', this.quiz.id, parseInt(resposta)).then((response) => {
        if (!response.success) {
          swal({
            title: traducao(response.message),
            icon: "warning"
          });
        }
      });
    },
    getClassEscolha: function (index) {
      return {
        "selecionada": this.respondida && index === this.meuJogador.respondidas[this.quiz.perguntaAtualIndex],
        "nao-selecionada": this.respondida && index !== this.meuJogador.respondidas[this.quiz.perguntaAtualIndex]
      };
    }
  }
}
</script>
